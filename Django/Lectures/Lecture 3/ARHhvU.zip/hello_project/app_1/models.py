from django.db import models
from django.conf import settings
from django.core.validators import MinLengthValidator

# Create your models here.
class Students(models.Model):
    roll_number = models.IntegerField()
    full_name = models.CharField(validators=[MinLengthValidator(2)], max_length=30)
    department = models.CharField(choices=settings.DEPARTMENT_NAMES)
    year = models.CharField(default='first', choices=[
        ('f', 'first'),
        ('s', 'second')
    ])


    def __str__(self):
        return self.full_name + ' ->' + str(self.roll_number) + '@' + self.department
