from django.core.management.base import BaseCommand, CommandError
from app_1.models import Students
from random import randint, choice
from faker import Faker

class Command(BaseCommand):
    help = "To Greet the user"

    def handle(self, *args, **options):
        fake = Faker()
        for i in range(100):
            new_student = {
                'roll_number': randint(1, 100),
                'full_name': fake.name(),
                'department': choice(['CS','GLG','AI','SE']),
                'year': choice(['f', 's'])
            }

            print(f"{new_student}")
            Students.objects.create(**new_student)

